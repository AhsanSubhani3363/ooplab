﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @char
{
    internal class Program
    {
        static void Main(string[] args)
        {

            char var = 'A';
            Console.WriteLine("character :");
            Console.Write(var);
            Console.ReadKey();
        }
    }
}
