﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ooplab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello world ");
            Console.Write("AHSAN SUBHANI HERE ");
        }
    }
}
